package uo.sdi.business.impl.admin;

import javax.ejb.Remote;

import uo.sdi.business.AdminService;

@Remote
public interface RemoteAdminService extends AdminService {

}

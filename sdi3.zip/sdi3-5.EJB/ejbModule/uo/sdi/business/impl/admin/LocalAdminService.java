package uo.sdi.business.impl.admin;

import javax.ejb.Local;

import uo.sdi.business.AdminService;

@Local
public interface LocalAdminService extends AdminService{

}

package uo.sdi.business.impl.user;

import javax.ejb.Local;

import uo.sdi.business.UserService;

@Local
public interface LocalUserService extends UserService {

}

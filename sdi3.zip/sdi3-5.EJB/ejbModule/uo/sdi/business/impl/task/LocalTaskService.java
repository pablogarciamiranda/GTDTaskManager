package uo.sdi.business.impl.task;

import javax.ejb.Local;

import uo.sdi.business.TaskService;

@Local
public interface LocalTaskService extends TaskService{

}

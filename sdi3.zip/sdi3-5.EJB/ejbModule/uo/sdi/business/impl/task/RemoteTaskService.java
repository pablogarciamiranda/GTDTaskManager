package uo.sdi.business.impl.task;

import javax.ejb.Remote;

import uo.sdi.business.TaskService;

@Remote
public interface RemoteTaskService extends TaskService {

}

package uo.sdi.dto.types;

public enum UserStatus {

	ENABLED, DISABLED
	
}

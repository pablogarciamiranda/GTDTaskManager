export class Category {

    constructor(public id: number, public title:string, public userId:number){
    }
}

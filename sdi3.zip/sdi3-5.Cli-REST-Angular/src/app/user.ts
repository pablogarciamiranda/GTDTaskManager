export class User {

    constructor(public id: number, public login:string, public email:string, public password:string, public isAdmin:boolean, public status:boolean){
    }
}

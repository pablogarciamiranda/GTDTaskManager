package uo.sdi.client.types;

public enum UserStatus {

	ENABLED, DISABLED
	
}
